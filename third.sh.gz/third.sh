#!/bin/sh
# This is a shell archive (produced by GNU sharutils 4.11.1).
# To extract the files from this archive, save it to some FILE, remove
# everything before the `#!/bin/sh' line above, then type `sh FILE'.
#
lock_dir=_sh23403
# Made on 2015-03-07 14:15 GMT by <work@work>.
# Source directory was `/home/work/documents/prj/github/forthlib'.
#
# Existing files will *not* be overwritten, unless `-c' is specified.
#
# This shar contains:
# length mode       name
# ------ ---------- ------------------------------------------
#   9164 -rw------- third/buzzard.2.hint
#    245 -rw------- third/demo3.th
#    135 -rw------- third/demo2.th
#  25773 -rw------- third/buzzard.2.design
#    116 -rw------- third/makefile
#    388 -rw------- third/demo6.th
#    791 -rw------- third/buzzard.2.c
#   6605 -rw------- third/third.th
#    339 -rw------- third/demo5.th
#     10 -rw------- third/.gitignore
#    212 -rw------- third/demo1.1st
#   1774 -rw------- third/help.th
#    756 -rw------- third/buzzard.2.README
#    794 -rw------- third/buzzard.2.orig.c
#    439 -rw------- third/demo4.th
#     34 -rw------- third/demo1.th
#
MD5SUM=${MD5SUM-md5sum}
f=`${MD5SUM} --version | egrep '^md5sum .*(core|text)utils'`
test -n "${f}" && md5check=true || md5check=false
${md5check} || \
  echo 'Note: not verifying md5sums.  Consider installing GNU coreutils.'
if test "X$1" = "X-c"
then keep_file=''
else keep_file=true
fi
echo=echo
save_IFS="${IFS}"
IFS="${IFS}:"
gettext_dir=
locale_dir=
set_echo=false

for dir in $PATH
do
  if test -f $dir/gettext \
     && ($dir/gettext --version >/dev/null 2>&1)
  then
    case `$dir/gettext --version 2>&1 | sed 1q` in
      *GNU*) gettext_dir=$dir
      set_echo=true
      break ;;
    esac
  fi
done

if ${set_echo}
then
  set_echo=false
  for dir in $PATH
  do
    if test -f $dir/shar \
       && ($dir/shar --print-text-domain-dir >/dev/null 2>&1)
    then
      locale_dir=`$dir/shar --print-text-domain-dir`
      set_echo=true
      break
    fi
  done

  if ${set_echo}
  then
    TEXTDOMAINDIR=$locale_dir
    export TEXTDOMAINDIR
    TEXTDOMAIN=sharutils
    export TEXTDOMAIN
    echo="$gettext_dir/gettext -s"
  fi
fi
IFS="$save_IFS"
if (echo "testing\c"; echo 1,2,3) | grep c >/dev/null
then if (echo -n test; echo 1,2,3) | grep n >/dev/null
     then shar_n= shar_c='
'
     else shar_n=-n shar_c= ; fi
else shar_n= shar_c='\c' ; fi
f=shar-touch.$$
st1=200112312359.59
st2=123123592001.59
st2tr=123123592001.5 # old SysV 14-char limit
st3=1231235901

if touch -am -t ${st1} ${f} >/dev/null 2>&1 && \
   test ! -f ${st1} && test -f ${f}; then
  shar_touch='touch -am -t $1$2$3$4$5$6.$7 "$8"'

elif touch -am ${st2} ${f} >/dev/null 2>&1 && \
   test ! -f ${st2} && test ! -f ${st2tr} && test -f ${f}; then
  shar_touch='touch -am $3$4$5$6$1$2.$7 "$8"'

elif touch -am ${st3} ${f} >/dev/null 2>&1 && \
   test ! -f ${st3} && test -f ${f}; then
  shar_touch='touch -am $3$4$5$6$2 "$8"'

else
  shar_touch=:
  echo
  ${echo} 'WARNING: not restoring timestamps.  Consider getting and
installing GNU `touch'\'', distributed in GNU coreutils...'
  echo
fi
rm -f ${st1} ${st2} ${st2tr} ${st3} ${f}
#
if test ! -d ${lock_dir} ; then :
else ${echo} "lock directory ${lock_dir} exists"
     exit 1
fi
if mkdir ${lock_dir}
then ${echo} "x - created lock directory ${lock_dir}."
else ${echo} "x - failed to create lock directory ${lock_dir}."
     exit 1
fi
# ============= third/buzzard.2.hint ==============
if test ! -d 'third'; then
  mkdir 'third'
if test $? -eq 0
then ${echo} "x - created directory third."
else ${echo} "x - failed to create directory third."
     exit 1
fi
fi
if test -n "${keep_file}" && test -f 'third/buzzard.2.hint'
then
${echo} "x - SKIPPING third/buzzard.2.hint (file already exists)"
else
${echo} "x - extracting third/buzzard.2.hint (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/buzzard.2.hint' &&
Best Language Tool:
X
X	Sean Barrett
X	Software Construction Company
X	430 Southwest Parkway, #1906
X	College Station, TX 77840
X	USA
X
X
Judges' comments:
X
X    First:
X	make first
X    
X    Second:
X	echo help | cat third help.th - | first
X	cat third demo5.th | first
X    
X    Third:
X	cat third help.th - | first
X
X	Wait until Ok is printed and the type:
X	    2 3 + . cr	    <-- yes you should really type the 2 letters: cr
X
X    Forth:
X	Sorry, this is third!
X
X
Selected notes from the author:
X
X    What it does:
X
X        first implements a relatively primitive stack machine.  How
X        primitive?  It supplies 13 visible primitives: 3 arithmetic,
X        1 comparison, 2 memory-access, 2 character I/O, 3 primitives
X        for defining new words, 1 tokenizing, and 1 special stack
X        operation.  (There are also three internal operations for
X        the stack machine: 'push this integer', 'call this code',
X        and 'compile a call to this code'.)
X
X        It is very difficult to accomplish anything with this set
X        of primitives, but they do have an interesting property.
X
X        This--what this interesting property is, or in other words
X        what first is good for--is the major obfuscation; there are
X        also minor source obfuscations, as well as some design tricks
X        that are effectively obfuscations.  Details on the obfuscations
X        are below, and the interesting property is discussed much
X        further down.
X
X
X    How to run it:
X
X        first expects you to first enter the names of the 13 primitives,
X        separated by whitespace--it doesn't care what you name them, but
X        if all the names aren't unique, you won't be able to use some of
X        them.  After this you may type any sequence of valid first input.
X        Valid first input is defined as any sequence of whitespace-delimited
X        tokens which consist of primitives, new words you've defined, and
X        integers (as parsed by "%d").  Invalid input behaves unpredictably,
X        but gives no warning messages.  A sample program, demo1.1st, is
X        included, but it only works on ASCII systems.
X
X        Do not expect to be able to do anything interesting with first.
X
X        To do something interesting, you need to feed first the file
X        third first.  In unix, you can do
X
X                % cat third help.th - | first
X
X        to do this.  Hopefully most operating systems will provide a
X        way to do this.  It may take some time for this to complete
X	(I seem to remember it taking several minutes on an 8086 PC);
X        THIRD will prompt you when it is finished.  The file third has
X        not been obfuscated, due to sheer kindness on the author's part.
X
X        For more information on what you can do once you've piped
X        THIRD into first, type 'help' and consult FORTH manuals for
X        further reference.  Six sample THIRD programs are included
X	in the files demo[1-6].th.  buzzard.2.README has more
X	information.
X
X        Keep in mind that you are still running first, and
X        are for the most part limited by first's tokenizer
X        (notably, unknown words will attempt to be parsed as
X        integers.)  It is possible to build a new parser that
X        parses by hand, reading a single character at a time;
X	however, such a parser cannot easily use the existing
X	dictionary, and so would have to implement its own,
X	thus requiring reimplementing all of first and third
X	a second time--I did not care to tackle this project.
X
X
X    Compiling:
X
X        first is reasonably portable.  You may need to adjust the
X        size of the buffers on smaller machines; m[] needs to be
X        at least 2000 long, though.
X
X        I say first is portable mainly because it uses native types.
X        Unlike FORTH, which traditionally allows byte and multi-byte
X        operations, all operations are performed on C 'int's.  That
X        means first code is only as portable as the same code would
X        be in C.  As in C, the result of dividing -1 by 2 is machine
X        (or rather compiler) dependent.
X
X    How is first obfuscated?
X
X        first is obfuscated in several ways.  Some minor obfuscations
X        like &w[&m[1]][s] for s+m[w+1] were in the original source
X	but are no longer because, apparently, ANSI doesn't allow it
X	(gcc -ansi -pedantic doesn't mind it, though.)
X	Other related obfuscations are still present.  The top of the
X	stack is cached in a variable, which increases performance
X	massively if the compiler can figure out to keep it in a register;
X	it also obfuscates the code.  (Unfortunately, the top of stack
X	is a global variable and neither gcc nor most bundled compilers
X	seem to register allocate it.)
X	
X        More significant are the design obfuscations.  m[0] is the
X        "dictionary pointer", used when compiling words, and m[1] is
X        the return stack index.  Both are used as integer offsets into
X        m.  Both are kept in m, instead of as separate pointers,
X        because they are then accessible to first programs, which is a
X        crucial property of first.  Similarly the way words are stored
X        in the dictionary is not obvious, so it can be difficult to
X        follow exactly what the compiler words are doing.
X
X        Assuming you've waded through all that, you still have
X        to penetrate the most significant obfuscation.  Traditionally,
X        the question is whether a reader can answer the question "what
X        will this do when I run it".  A reader who has deciphered first
X        to this point may think they know the answer to this question,
X        but they may not know the answer to the more important question,
X        "what will this program do when given the right input?"  FORTH
X        afficianados, and especially FORTH implementors, may recognize
X        the similarity of the internal compiler format to many FORTH
X        interal representations, and, being aware that FORTH interpreters
X        can often by self-compiling, may be suspicious that this program
X        can compile FORTH, or a significant subset of it, or at least be
X        capable of doing so if fed the right input.  Of course, the name
X        "THIRD" should be a dead giveaway, if the name "first" wasn't.
X        (These numbers were largely chosed because they were five letters
X        long, like "FORTH", and would not require truncation to five
X        letters, which would be a dead giveaway.  Besides, THIRD represents
X        a step backwards, in more ways than one.)
X
X
X    What exactly is first, then?
X
X    first is a tiny interpreter which implements a sufficient
X    pseudo-subset of FORTH to allow it to bootstrap a relatively
X    complete version of FORTH (based loosely on forth79), which
X    I call THIRD.  Complete relative to what, I'm not sure.
X
X    I believe first is close to the smallest amount of code possible
X    to get this effect *using forth-style primitives*, and still have
X    some efficiency (it is possible to get by without multiplication
X    if you have addition, obviously).  In the design file, design,
X    I give a justification for why each primitive in first was included.
X
X    THIRD is sorta slow, because first has so few primitives that
X    many things that are primitives in FORTH (like swap) take a
X    significant amount of time in THIRD.
X
X    When you get the 'Ok.' message from third, try out some sample
X    FORTH code (first has no way of knowing if keyboard input is
X    waiting, so it can't actually prompt you in a normal way.  It
X    only prints 'Ok.' after you define a word).
X
X        2 3 + . cr    ( add 2 and 3, and print it and a newline.)
X
X    and THIRD responds
X
X        5
X
X    Now try:
X
X        : test 11 1 do i . loop cr ;
X        test
X
X    and THIRD responds
X
X        1 2 3 4 5 6 7 8 9 10
X
X
X    When in THIRD, you can see how much space you're currently
X    using by typing
X
X        here .
X
X    The number THIRD replies is the number of machine words (ints)
X    that the dictionary (the first code) takes up, plus the
X    512 ints for the return stack.  If you compile the basic
X    THIRD system without the help word (strings take up one
X    int per character in the string!), you should find that
X    you're using around 1000 ints (plus the return stack).
X
X    Thus THIRD gives you a relatively complete FORTH system in
X    less than 700 chars of C source + about 1000 ints of
X    memory--and it's portable too (you could copy over the
X    THIRD memory dump to another machine, in theory).  If the
X    above numbers seem to you to be mixing apples and oranges
X    (C source and compiled THIRD code), note that you should
X    in theory be able to stick the compiled THIRD code into
X    the C source.
X
X
X    Software Construction Company gets credit for rekindling
X    my interest in FORTH and thus indirectly inspiring me
X    to write this program.
X
Copyright (c) 1992, Landon Curt Noll & Larry Bassel.
All Rights Reserved.  Permission for personal, educational or non-profit use is
granted provided this this copyright and notice are included in its entirety
and remains unaltered.  All other uses must receive prior permission in writing
from both Landon Curt Noll and Larry Bassel.
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/buzzard.2.hint'
   eval "${shar_touch}") && \
  chmod 0600 'third/buzzard.2.hint'
if test $? -ne 0
then ${echo} "restore of third/buzzard.2.hint failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/buzzard.2.hint': 'MD5 check failed'
       ) << \SHAR_EOF
fd42298cb940ae92c370c829eacc3990  third/buzzard.2.hint
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/buzzard.2.hint'` -ne 9164 && \
  ${echo} "restoration warning:  size of 'third/buzzard.2.hint' is not 9164"
  fi
fi
# ============= third/demo3.th ==============
if test ! -d 'third'; then
  mkdir 'third'
if test $? -eq 0
then ${echo} "x - created directory third."
else ${echo} "x - failed to create directory third."
     exit 1
fi
fi
if test -n "${keep_file}" && test -f 'third/demo3.th'
then
${echo} "x - SKIPPING third/demo3.th (file already exists)"
else
${echo} "x - extracting third/demo3.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo3.th' &&
: printfour
X
X	dup		( save the number on top of the stack )
X	4 =		( compare it to four )
X	if
X	  " forth "	( output a string for it )
X	  drop		( and delete the saved value )
X        else
X	  .
X	endif
;
X
: demo3 10 0 do i printfour loop cr ;
X
demo3
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo3.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo3.th'
if test $? -ne 0
then ${echo} "restore of third/demo3.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo3.th': 'MD5 check failed'
       ) << \SHAR_EOF
864f87c2fa01a20f82e7e7731a7901f2  third/demo3.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo3.th'` -ne 245 && \
  ${echo} "restoration warning:  size of 'third/demo3.th' is not 245"
  fi
fi
# ============= third/demo2.th ==============
if test -n "${keep_file}" && test -f 'third/demo2.th'
then
${echo} "x - SKIPPING third/demo2.th (file already exists)"
else
${echo} "x - extracting third/demo2.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo2.th' &&
: demo2 
X
X	10 0		( iterate from 0 stopping before 10 )
X	do
X	    i .  	( print the loop counter )
X	loop
X	cr		( add a newline )
;
X
demo2
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo2.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo2.th'
if test $? -ne 0
then ${echo} "restore of third/demo2.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo2.th': 'MD5 check failed'
       ) << \SHAR_EOF
b327043e3037bd78feecfa891c205517  third/demo2.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo2.th'` -ne 135 && \
  ${echo} "restoration warning:  size of 'third/demo2.th' is not 135"
  fi
fi
# ============= third/buzzard.2.design ==============
if test -n "${keep_file}" && test -f 'third/buzzard.2.design'
then
${echo} "x - SKIPPING third/buzzard.2.design (file already exists)"
else
${echo} "x - extracting third/buzzard.2.design (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/buzzard.2.design' &&
X			FIRST & THIRD
X			almost FORTH
X
X    FORTH is a language mostly familiar to users of "small" machines.
FORTH programs are small because they are interpreted--a function
call in FORTH takes two bytes.  FORTH is an extendable language--
built-in primitives are indistinguishable from user-defined
_words_.  FORTH interpreters are small because much of the system
can be coded in FORTH--only a small number of primitives need to
be implemented.  Some FORTH interpreters can also compile defined
words into machine code, resulting in a fast system.
X
X    FIRST is an incredibly small language which is sufficient for
defining the language THIRD, which is mostly like FORTH.  There are
some differences, and THIRD is probably just enough like FORTH for
those differences to be disturbing to regular FORTH users.
X
X    The only existing FIRST interpreter is written in obfuscated C,
and rings in at under 800 bytes of source code, although through
deletion of whitespace and unobfuscation it can be brought to about
650 bytes.
X
X    This document FIRST defines the FIRST environment and primitives,
with relevent design decision explanations.  It secondly documents
the general strategies we will use to implement THIRD.  The THIRD
section demonstrates how the complete THIRD system is built up
using FIRST.
X
X
Section 1:  FIRST
X
X
Environment
X
X    FIRST implements a virtual machine.  The machine has three chunks
of memory: "main memory", "the stack", and "string storage".  When
the virtual machine wishes to do random memory accesses, they come
out of main memory--it cannot access the stack or string storage.
X
X    The stack is simply a standard LIFO data structure that is used
implicitly by most of the FIRST primitives.  The stack is made up
of ints, whatever size they are on the host machine.
X
X    String storage is used to store the names of built-in and defined
primitives.  Separate storage is used for these because it allows
the C code to use C string operations, reducing C source code size.
X
X    Main memory is a large array of ints.  When we speak of
addresses, we actually mean indices into main memory.  Main memory
is used for two things, primarily: the return stack and the dictionary.
X
X    The return stack is a LIFO data structure, independent of
the abovementioned "the stack", which is used by FIRST to keep
track of function call return addresses.
X
X    The dictionary is a list of words.  Each word contains a header
and a data field.  In the header is the address of the previous word,
an index into the string storage indicating where the name of this
word is stored, and a "code pointer".  The code pointer is simply
an integer which names which "machine-language-primitive" implements
this instruction.  For example, for defined words the code pointer
names the "run some code" primitive, which pushes the current program
counter onto the return stack and sets the counter to the address of
the data field for this word.
X
X    There are several important pointers into main memory.  There is
a pointer to the most recently defined word, which is used to start
searches back through memory when compiling words.  There is a pointer
to the top of the return stack.  There is a pointer to the current
end of the dictionary, used while compiling.
X
X    For the last two pointers, namely the return stack pointer and
the dictionary pointer, there is an important distinction: the pointers
themselves are stored in main memory (in FIRST's main memory).  This
is critical, because it means FIRST programs can get at them without
any further primitives needing to be defined.
X
X
Instructions
X
X    There are two kinds of FIRST instructions, normal instructions and
immediate instructions.  Immediate instructions do something significant
when they are used.  Normal instructions compile a pointer to their
executable part onto the end of the dictionary.  As we will see, this
means that by default FIRST simply compiles things.
X
X  Integer Operations
Symbol	Name		Function
X  -	binary minus	pop top 2 elements of stack, subtract, push
X  *	multiply	pop top 2 elements of stack, multiply, push
X  /	divide		pop top 2 elements of stack, divide, push
X  <0	less than 0	pop top element of stack, push 1 if < 0 else 0
X
Note that we can synthesize addition and negation from binary minus,
but we cannot synthesize a time efficient divide or multiply from it.
<0 is synthesizable, but only nonportably.
X
X  Memory Operations
Symbol	Name		Function
X  @	fetch		pop top of stack, treat as address to push contents of
X  !	store		top of stack is address, 2nd is value; store to memory
X				and pop both off the stack
X
X  Input/Output Operations
Name			Function
echo			output top of stack through C's putchar()
key			push C's getchar() onto top of stack
_read			read a space-delimited word, find it in the
X				dictionary, and compile a pointer to
X				that word's code pointer onto the
X				current end of the dictionary
X
Although _read could be synthesized from key, we need _read to be able
to compile words to be able to start any syntheses.
X
X  Execution Operations
Name			Function
exit			leave the current function: pop the return stack
X				into the program counter
X
X  Immediate (compilation) Operations
Symbol	Name		Function
X  :	define		read in the next space-delimited word, add it to
X				the end of our string storage, and generate
X				a header for the new word so that when it
X				is typed it compiles a pointer to itself
X				so that it can be executed.
immediate immediate	when used immediately after a name following a ':',
X				makes the word being defined run whenever
X				it is typed.
X
: cannot be synthesized, because we could not synthesize anything.
immediate has to be an immediate operation, so it could not be
synthesized unless by default operations were immediate; but that
would preclude our being able to do any useful compilation.
X
X  Stack Operations
Name			Function
pick			pop top of stack, use as index into stack and copy up
X				that element
X
If the data stack were stored in main memory, we could synthesize pick;
but putting the stack and stack pointer in main memory would significantly
increase the C source code size.
X
X    There are three more primitives, but they are "internal only"--
they have no names and no dictionary entries.  The first is
"pushint".  It takes the next integer out of the instruction stream
and pushes it on the stack.  This could be synthesized, but probably
not without using integer constants.  It is generated by _read when
the input is not a known word.  The second is "compile me".  When
this instruction is executed, a pointer to the word's data field is
appended to the dictionary.  The third is "run me"--the word's data
field is taken to be a stream of pointers to words, and is executed.
X
X    One last note about the environment: FIRST builds a very small
word internally that it executes as its main loop.  This word calls
_read and then calls itself.  Each time it calls itself, it uses
up a word on the return stack, so it will eventually trash things.
This is discussed some more in section 2.
X
X
Here's a handy summary of all the FIRST words:
X
X	- * /		binary integer operations on the stack
X	<0		is top of stack less than 0?
X	@ !		read from or write to memory
X	echo key	output or input one character
X	_read		read a word from input and compile a pointer to it
X	exit		stop running the current function
X	:		compile the header of a definition
X	immediate	modify the header to create an immediate word
X
X    Here is a sample FIRST program.  I'm assuming you're using
the ASCII character set.  FIRST does not depend upon ASCII, but
since FIRST has no syntax for character constants, one normally has
to use decimal values.  This can be gotten around using getchar, though.
Oh.  One other odd thing.  FIRST initially builds its symbol table
by calling : several times, so it needs to get the names of the base
symbols as its first 13 words of input.  You could even name them
differently if you wanted.
X    These FIRST programs have FORTH comments in them: they are contained
inside parentheses.  FIRST programs cannot have FORTH comments; but I need
some device to indicate what's going on.  (THIRD programs are an entirely
different subject.)
X
X	( Our first line gives the symbols for the built-ins )
: immediate _read @ ! - * / <0 exit echo key _pick
X
X	( now we define a simple word that will print out a couple characters )
X
: L			( define a word named 'L' )
X  108 echo		( output an ascii 'l' )
X  exit
X
: hello			( define a word named 'hello')
X  72 echo		( output an ascii 'H' )
X  101 echo		( output an ascii 'e' )
X  111			( push ascii 'o' onto the stack )
X  L L			( output two ascii 'l's )
X  echo			( output the 'o' we pushed on the stack before )
X  10 echo		( print a newline )
X  exit			( stop running this routine )
X
: test immediate	( define a word named 'test' that runs whenever typed )
X  hello			( call hello )
X  exit
X
test
X
( The result of running this program should be: 
Hello
)
X
X
Section 2: Motivating THIRD
X
X    What is missing from FIRST?  There are a large number of
important primitives that aren't implemented, but which are
easy to implement.  drop , which throws away the top of the
stack, can be implemented as { 0 * + } -- that is, multiply
the top of the stack by 0 (which turns the top of the stack
into a 0), and then add the top two elements of the stack.
X
X    dup , which copies the top of the stack, can be easily
implemented using temporary storage locations.  Conveniently,
FIRST leaves memory locations 3, 4, and 5 unused.  So we can
implement dup by writing the top of stack into 3, and then
reading it out twice: { 3 ! 3 @ 3 @ }.
X
X    we will never use the FIRST primitive 'pick' in building THIRD,
just to show that it can be done; 'pick' is only provided because
pick itself cannot be built out of the rest of FIRST's building
blocks.
X
X    So, instead of worrying about stack primitives and the
like, what else is missing from FIRST?  We get recursion, but
no control flow--no conditional operations.  We cannot at the
moment write a looping routine which terminates.
X
X    Another glaring dissimilarity between FIRST and FORTH is
that there is no "command mode"--you cannot be outside of a
: definition and issue some straight commands to be executed.
Also, as we noted above, we cannot do comments.
X
X    FORTH also provides a system for defining new data types,
using the words [in one version of FORTH] <builds and does> .
We would like to implement these words as well.
X
X    As the highest priority thing, we will build control flow
structures first.  Once we have control structures, we can
write recursive routines that terminate, and we are ready to
tackle tasks like parsing, and the building of a command mode.
X
X    By the way, location 0 holds the dictionary pointer, location
1 holds the return stack pointer, and location 2 should always
be 0--it's a fake dictionary entry that means "pushint".
X
X
Section 3: Building THIRD
X
X		In this section, I'm going to keep my conversation
X		indented to this depth, rather than using fake comments--
X		because we'll have real comments eventually.
X
X		The first thing we have to do is give the symbols for our
X		built-ins.
X
: immediate _read @ ! - * / < exit echo key _pick
X
X		Next we want to be mildly self commenting, so we define
X		the word 'r' to push the *address of the return stack
X		pointer* onto the stack--NOT the value of the return 
X		stack pointer.  (In fact, when we run r, the value of
X		the return stack pointer is temporarily changed.)
X
: r 1 exit
X
X		Next, we're currently executing a short loop that contains
X		_read and recursion, which is slowly blowing up the return
X		stack.  So let's define a new word, from which you can
X		never return.  What it does is drops the top value off
X		the return stack, calls _read, then calls itself.  Because
X		it kills the top of the return stack, it can recurse
X		indefinitely.
X
: ]
X  r @			Get the value of the return stack pointer
X  1 -			Subtract one
X  r !			Store it back into the return stack pointer
X  _read			Read and compile one word
X  ]			Start over
X
X		Notice that we don't need to exit, since we never come
X		back.  Also, it's possible that an immediate word may
X		get run during _read, and that _read will never return!
X
X		Now let's get compile running.
X
: main immediate ]
main
X
X		Next off, I'm going to do this the easy but non-portable
X		way, and put some character constant definitions in.
X		I wanted them at the top of the file, but that would have
X		burned too much of the return stack.
X
: '"'	34	exit
: ')'	41	exit
: '\n'	10	exit
: 'space' 32	exit
: '0'	48	exit
: '-'	45	exit
X
: cr '\n' echo exit
X
X		Next, we want to define some temporary variables for
X		locations 3, 4, and 5, since this'll make our code look
X		clearer.
: _x 3 @ exit
: _x! 3 ! exit
: _y 4 @ exit
: _y! 4 ! exit
X
X		Ok.  Now, we want to make THIRD look vaguely like FORTH,
X		so we're going to define ';'.  What ; ought to do is
X		terminate a compilation, and turn control over to the
X		command-mode handler.  We don't have one, so all we want
X		';' to do for now is compile 'exit' at the end of the
X		current word.  To do this we'll need several other words.
X		
X		Swap by writing out the top two elements into temps, and
X		then reading them back in the other order.
: swap _x! _y! _x _y exit
X		Take another look and make sure you see why that works,
X		since it LOOKS like I'm reading them back in the same
X		order--in fact, it not only looks like it, but I AM!
X
X		Addition might be nice to have.  To add, we need to
X		negate the top element of the stack, and then subtract.
X		To negate, we subtract from 0.
: +
X  0 swap -
X  -
X  exit
X
X		Create a copy of the top of stack
: dup _x! _x _x exit
X
X		Get a mnemonic name for our dictionary pointer--we need
X		to compile stuff, so it goes through this.
: h 0 exit
X
X		We're going to need to advance that pointer, so let's
X		make a generic pointer-advancing function.
X		Given a pointer to a memory location, increment the value
X		at that memory location.
: inc
X  dup @			Get another copy of the address, and get the value
X			so now we have value, address on top of stack.
X  1 +			Add one to the value
X  swap			Swap to put the address on top of the stack
X  ! exit		Write it to memory
X
X		, is a standard FORTH word.  It should write the top of 
X		stack into the dictionary, and advance the pointer
: ,
X  h @			Get the value of the dictionary pointer
X  !			Write the top of stack there
X  h inc			And increment the dictionary pointer
X  exit
X
X		' is a standard FORTH word.  It should push the address
X		of the word that follows it onto the stack.  We could
X		do this by making ' immediate, but then it'd need to
X		parse the next word.  Instead, we compile the next word
X		as normal.  When ' is executed, the top of the return
X		stack will point into the instruction stream immediately
X		after the ' .  We push the word there, and advance the
X		return stack pointer so that we don't execute it.
: '
X  r @			Get the address of the top of return stack
X			We currently have a pointer to the top of return stack
X  @			Get the value from there
X			We currently have a pointer to the instruction stream
X  dup			Get another copy of it--the bottom copy will stick
X				around until the end of this word
X  1 +			Increment the pointer, pointing to the NEXT instruction
X  r @ !			Write it back onto the top of the return stack
X			We currently have our first copy of the old pointer
X				to the instruction stream
X  @			Get the value there--the address of the "next word"
X  exit
X
X		Now we're set.  ; should be an immediate word that pushes
X		the address of exit onto the stack, then writes it out.
: ; immediate
X  ' exit 		Get the address of exit
X  ,			Compile it
X  exit			And we should return
X
X		Now let's test out ; by defining a useful word:
: drop 0 * + ;
X
X		Since we have 'inc', we ought to make 'dec':
: dec dup @ 1 - swap ! ;
X
X		Our next goal, now that we have ;, is to implement
X		if-then.  To do this, we'll need to play fast and
X		loose with the return stack, so let's make some
X		words to save us some effort.
X
X		First we want a word that pops off the top of the normal
X		stack and pushes it on top of the return stack.  We'll
X		call this 'tor', for TO-Return-stack.   It sounds easy,
X		but when tor is running, there's an extra value on the
X		return stack--tor's return address!  So we have to pop
X		that off first...  We better just bite the bullet and
X		code it out--but we can't really break it into smaller
X		words, because that'll trash the return stack.
: tor
X  r @ @			Get the value off the top of the return stack
X  swap			Bring the value to be pushed to the top of stack
X  r @ !			Write it over the current top of return stack
X  r @ 1 + r !		Increment the return stack pointer--but can't use inc
X  r @ !			Store our return address back on the return stack
;
X
X		Next we want the opposite routine, which pops the top
X		of the return stack, and puts it on the normal stack.
: fromr
X  r @ @			Save old value
X  r @ 1 - r !		Decrement pointer
X  r @ @			Get value that we want off
X  swap			Bring return address to top
X  r @ !			Store it and return
;
X
X		Now, if we have a routine that's recursing, and we
X		want to be polite about the return stack, right before
X		we recurse we can run { fromr drop } so the stack won't
X		blow up.  This means, though, that the first time we
X		enter this recursive routine, we blow our *real* return
X		address--so when we're done, we'll return up two levels.
X		To save a little, we make 'tail' mean { fromr drop };
X		however, it's more complex since there's a new value on
X		top of the return stack.
: tail fromr fromr drop tor ;
X
X		Now, we want to do 'if'.  To do this, we need to convert
X		values to boolean values.  The next few words set this
X		up.	
X
X		minus gives us unary negation.
: minus 0 swap - ;
X
X		If top of stack is boolean, bnot gives us inverse
: bnot 1 swap - ;
X
X		To compare two numbers, subtract and compare to 0.
: < - <0 ;
X
X		logical turns the top of stack into either 0 or 1.
: logical
X  dup			Get two copies of it
X  0 <			1 if < 0, 0 otherwise
X  swap minus		Swap number back up, and take negative
X  0 <			1 if original was > 0, 0 otherwise
X  +			Add them up--has to be 0 or 1!
;
X
X		not returns 1 if top of stack is 0, and 0 otherwise
: not logical bnot ;
X
X		We can test equality by subtracting and comparing to 0.
: = - not ;
X
X		Just to show how you compute a branch:  Suppose you've
X		compiled a call to branch, and immediately after it is
X		an integer constant with the offset of how far to branch.
X		To branch, we use the return stack to read the offset, and
X		add that on to the top of the return stack, and return.
: branch
X  r @			Address of top of return stack
X  @			Our return address
X  @			Value from there: the branch offset
X  r @ @			Our return address again
X  +			The address we want to execute at
X  r @ !			Store it back onto the return stack
;
X
X		For conditional branches, we want to branch by a certain
X		amount if true, otherwise we want to skip over the branch
X		offset constant--that is, branch by one.  Assuming that
X		the top of the stack is the branch offset, and the second
X		on the stack is 1 if we should branch, and 0 if not, the
X		following computes the correct branch offset.
: computebranch 1 - * 1 + ;
X
X		Branch if the value on top of the stack is 0.
: notbranch
X  not
X  r @ @ @		Get the branch offset
X  computebranch		Adjust as necessary
X  r @ @ +		Calculate the new address
X  r @ !			Store it
;
X
X		here is a standard FORTH word which returns a pointer to
X		the current dictionary address--that is, the value of
X		the dictionary pointer.
: here h @ ;
X
X		We're ALL SET to compile if...else...then constructs!
X		Here's what we do.  When we get 'if', we compile a call
X		to notbranch, and then compile a dummy offset, because
X		we don't know where the 'then' will be.  On the *stack*
X		we leave the address where we compiled the dummy offset.
X		'then' will calculate the offset and fill it in for us.
: if immediate
X  ' notbranch ,		Compile notbranch
X  here			Save the current dictionary address
X  0 ,			Compile a dummy value
;
X
X		then expects the address to fixup to be on the stack.
: then immediate
X  dup			Make another copy of the address
X  here			Find the current location, where to branch to
X  swap -		Calculate the difference between them
X  swap !		Bring the address to the top, and store it.
;
X
X		Now that we can do if...then statements, we can do
X		some parsing!  Let's introduce real FORTH comments.
X		find-) will scan the input until it finds a ), and
X		exit.
: find-)
X  key			Read in a character
X  ')' =			Compare it to close parentheses
X  not if		If it's not equal
X    tail find-)		repeat (popping R stack)
X  then			Otherwise branch here and exit
;
X
: ( immediate
X  find-)
;
X
( we should be able to do FORTH-style comments now )
X
( now that we've got comments, we can comment the rest of the code
X  in a legitimate [self parsing] fashion.  Note that you can't
X  nest parentheses... )
X
: else immediate
X  ' branch ,		( compile a definite branch )
X  here			( push the backpatching address )
X  0 ,			( compile a dummy offset for branch )
X  swap			( bring old backpatch address to top )
X  dup here swap -	( calculate the offset from old address )
X  swap !		( put the address on top and store it )
;
X
: over _x! _y! _y _x _y ;
X
: add
X  _x!			( save the pointer in a temp variable )
X  _x @			( get the value pointed to )
X  +			( add the incremement from on top of the stack )
X  _x !			( and save it )
;
X
: allot	h add ;
X
: maybebranch
X  logical		( force the TOS to be 0 or 1 )
X  r @ @ @		( load the branch offset )
X  computebranch		( calculate the condition offset [either TOS or 1])
X  r @ @ +		( add it to the return address )
X  r @ !			( store it to our return address and return )
;
X
: mod _x! _y!		( get x then y off of stack )
X  _y _y _x / _x *	( y - y / x * x )
X  -
;
X
: printnum
X  dup
X  10 mod '0' +
X  swap 10 / dup
X  if
X    printnum
X    echo
X  else
X    drop
X    echo
X  then
;
X
: .
X  dup 0 <
X  if
X    '-' echo minus
X  then
X  printnum
X  'space' echo
;
X
: debugprint dup . cr ;
X
( the following routine takes a pointer to a string, and prints it,
X  except for the trailing quote.  returns a pointer to the next word
X  after the trailing quote )
X
: _print
X  dup 1 +
X  swap @
X  dup '"' =
X  if
X    drop exit
X  then
X  echo
X  tail _print
;
X
: print _print ;
X
X  ( print the next thing from the instruction stream )
: immprint
X  r @ @
X  print
X  r @ !
;
X
: find-"
X  key dup ,
X  '"' =
X  if
X    exit
X  then
X  tail find-"
;
X
: " immediate
X  key drop
X  ' immprint ,
X  find-"
;
X
: do immediate
X  ' swap ,		( compile 'swap' to swap the limit and start )
X  ' tor ,		( compile to push the limit onto the return stack )
X  ' tor ,		( compile to push the start on the return stack )
X  here			( save this address so we can branch back to it )
;
X
: i r @ 1 - @ ;
: j r @ 3 - @ ;
X
: > swap < ;
: <= 1 + < ;
: >= swap <= ;
X
: inci 
X  r @ 1 - 	( get the pointer to i )
X  inc		( add one to it )
X  r @ 1 - @ 	( find the value again )
X  r @ 2 - @	( find the limit value )
X  <=
X  if
X    r @ @ @ r @ @ + r @ ! exit		( branch )
X  then
X  fromr 1 +
X  fromr drop
X  fromr drop
X  tor
;
X
: loop immediate ' inci @ here - , ;
X
: loopexit
X
X  fromr drop		( pop off our return address )
X  fromr drop		( pop off i )
X  fromr drop		( pop off the limit of i )
;			( and return to the caller's caller routine )
X
: execute
X  8 !
X  ' exit 9 !
X  8 tor
;
X
: :: ;          ( :: is going to be a word that does ':' at runtime )
X
: fix-:: immediate 3 ' :: ! ;
fix-::
X
X        ( Override old definition of ':' with a new one that invokes ] )
: : immediate :: ] ;
X
: command
X  here 5 !              ( store dict pointer in temp variable )
X  _read                 ( compile a word )
X                        ( if we get control back: )
X  here 5 @
X  = if
X    tail command        ( we didn't compile anything )
X  then
X  here 1 - h !          ( decrement the dictionary pointer )
X  here 5 @              ( get the original value )
X  = if
X    here @              ( get the word that was compiled )
X    execute             ( and run it )
X  else
X    here @              ( else it was an integer constant, so push it )
X    here 1 - h !        ( and decrement the dictionary pointer again )
X  then
X  tail command
;
X
: make-immediate        ( make a word just compiled immediate )
X  here 1 -              ( back up a word in the dictionary )
X  dup dup               ( save the pointer to here )
X  h !                   ( store as the current dictionary pointer )
X  @                     ( get the run-time code pointer )
X  swap                  ( get the dict pointer again )
X  1 -                   ( point to the compile-time code pointer )
X  !                     ( write run-time code pointer on compile-time pointer )
;
X
: <build immediate
X  make-immediate        ( make the word compiled so far immediate )
X  ' :: ,                ( compile '::', so we read next word )
X  2 ,                   ( compile 'pushint' )
X  here 0 ,              ( write out a 0 but save address for does> )
X  ' , ,                 ( compile a push that address onto dictionary )
;
X
: does> immediate
X  ' command ,           ( jump back into command mode at runtime )
X  here swap !           ( backpatch the build> to point to here )
X  2 ,                   ( compile run-code primitive so we look like a word )
X  ' fromr ,             ( compile fromr, which leaves var address on stack )
;
X
X
: _dump                 ( dump out the definition of a word, sort of )
X  dup " (" . " , "
X  dup @                 ( save the pointer and get the contents )
X  dup ' exit
X  = if
X        " ;)" cr exit
X  then
X  . " ), "
X  1 +
X  tail _dump
;
X
: dump _dump ;
X
: # . cr ;
X  
: var <build , does> ;
: constant <build , does> @ ;
: array <build allot does> + ;
X
: [ immediate command ;
: _welcome " Welcome to THIRD.
Ok.
" ;
X
: ; immediate ' exit , command exit
X
[
X
_welcome
X
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/buzzard.2.design'
   eval "${shar_touch}") && \
  chmod 0600 'third/buzzard.2.design'
if test $? -ne 0
then ${echo} "restore of third/buzzard.2.design failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/buzzard.2.design': 'MD5 check failed'
       ) << \SHAR_EOF
a3c71acd714e39fd397fe934288d5d21  third/buzzard.2.design
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/buzzard.2.design'` -ne 25773 && \
  ${echo} "restoration warning:  size of 'third/buzzard.2.design' is not 25773"
  fi
fi
# ============= third/makefile ==============
if test -n "${keep_file}" && test -f 'third/makefile'
then
${echo} "x - SKIPPING third/makefile (file already exists)"
else
${echo} "x - extracting third/makefile (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/makefile' &&
all: third
third: buzzard.2.o
X	$(CC) $< -o $@
run: third
X	cat third.th /dev/stdin | ./third
clean:
X	rm -f third *.o
SHAR_EOF
  (set 20 15 03 07 14 12 49 'third/makefile'
   eval "${shar_touch}") && \
  chmod 0600 'third/makefile'
if test $? -ne 0
then ${echo} "restore of third/makefile failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/makefile': 'MD5 check failed'
       ) << \SHAR_EOF
add1e316ab347e43c423a3f23ab56837  third/makefile
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/makefile'` -ne 116 && \
  ${echo} "restoration warning:  size of 'third/makefile' is not 116"
  fi
fi
# ============= third/demo6.th ==============
if test -n "${keep_file}" && test -f 'third/demo6.th'
then
${echo} "x - SKIPPING third/demo6.th (file already exists)"
else
${echo} "x - extracting third/demo6.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo6.th' &&
: foobar
X  2
X  [ 2 ,		  ( '[' turns the compiler off, allowing us to execute code )
X    1 1 1 + + ,   ( and we compile in-line a 2 and a three )
X		  ( the '2' means 'push the number following this' )
X  ]
X  + . cr
;
X
foobar
X
: 'foobar ' foobar ;    ( ' can only be run inside the compiler )
X			( ' leaves the address of the following word
X			    on the stack )
X
'foobar . cr
X
'foobar dump
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo6.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo6.th'
if test $? -ne 0
then ${echo} "restore of third/demo6.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo6.th': 'MD5 check failed'
       ) << \SHAR_EOF
3324396c4c46c88d3992b6153fa3a74b  third/demo6.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo6.th'` -ne 388 && \
  ${echo} "restoration warning:  size of 'third/demo6.th' is not 388"
  fi
fi
# ============= third/buzzard.2.c ==============
if test -n "${keep_file}" && test -f 'third/buzzard.2.c'
then
${echo} "x - SKIPPING third/buzzard.2.c (file already exists)"
else
${echo} "x - extracting third/buzzard.2.c (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/buzzard.2.c' &&
#define c m[m[0]++] =
#define z;break;case
X
char s[5000];
int m[20000]={32},L=1,I,T[500],*S=T,t=64,w,f;
X
a(x)
{
X   c L;
X   L= *m-1;
X   c t;
X   c x;
X   scanf("%s",s+t);
X   t+=strlen(s+t)+1;
}
X
r(x)
{
X   switch(m[x++]){
X	z 5:	for(w=scanf("%s",s)<1?exit(0),0:L;strcmp(s,&s[m[w+1]]);w=m[w]);
X		w-1 ? r(w+2) : (c 2,c atoi(s))
X	z 12:	I=m[m[1]--]
X	z 15:	f=S[-f]
X	z 1:	c x 
X	z 9:	f *=* S--
X	z 7:	m[f]= *S--;
X		f= *S--
X	z 0:	*++S=f;
X		f=m[I++]
X	z 8:	f= *S --- f
X	z 2:	m[++m[1]]=I;
X		I=x
X	z 11:	f=0>f
X	z 4:	*m-=2;c 2
X	z 6:	f=m[f]
X	z 10:	f= *S--/f
X	z 3:	a(1);
X		c 2
X	z 13:	putchar(f);
X		f= *S--
X	z 14:	*++S=f;
X		f=getchar();
X   }
}
X
main()
{
X   a(3);
X   a(4);
X   a(1);
X   w= *m;
X   c 5;
X   c 2;
X   I= *m;
X   c w;
X   c I-1;
X   for(w=6;w<16;)
X      a(1),c w++;
X   m[1]= *m;
X   for(*m+=512;;r(m[I++]));
}
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/buzzard.2.c'
   eval "${shar_touch}") && \
  chmod 0600 'third/buzzard.2.c'
if test $? -ne 0
then ${echo} "restore of third/buzzard.2.c failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/buzzard.2.c': 'MD5 check failed'
       ) << \SHAR_EOF
2ba4c29b34b5860d1806d915445d43fe  third/buzzard.2.c
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/buzzard.2.c'` -ne 791 && \
  ${echo} "restoration warning:  size of 'third/buzzard.2.c' is not 791"
  fi
fi
# ============= third/third.th ==============
if test -n "${keep_file}" && test -f 'third/third.th'
then
${echo} "x - SKIPPING third/third.th (file already exists)"
else
${echo} "x - extracting third/third.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/third.th' &&
: immediate _read @ ! - * / <0 exit echo key _pick
X
: debug immediate 1 5 ! exit
X
: r 1 exit
X
: ] r @ 1 - r ! _read ]
X
: _main immediate r @ 7 ! ]
_main
X
X
: _x 3 @ exit
: _y 4 @ exit
: _x! 3 ! exit
: _y! 4 ! exit
X
X
: swap _x! _y! _x _y exit
X
: + 0 swap - - exit
X
: dup _x! _x _x exit
X
: inc dup @ 1 + swap ! exit
X
: h 0 exit
X
: , h @ ! h inc exit
X
X
: ' r @ @ dup 1 + r @ ! @ exit
X
: ; immediate ' exit , exit
X
X
: drop 0 * + ;
X
: dec dup @ 1 - swap ! ;
X
: tor r @ @ swap r @ ! r @ 1 + r ! r @ ! ;
X
: fromr r @ @ r @ 1 - r ! r @ @ swap r @ ! ;
X
: tail fromr fromr drop tor ;
X
: minus 0 swap - ;
X
: bnot 1 swap - ;
X
: < - <0 ;
X
: logical dup 0 < swap minus 0 < + ;
X
: not logical bnot ;
X
: = - not ;
X
: branch r @ @ @ r @ @ + r @ ! ;
X
: computebranch 1 - * 1 + ;
X
: notbranch
X  not
X  r @ @ @
X  computebranch
X  r @ @ +
X  r @ !
;
X
: here h @ ;
X
: if immediate ' notbranch , here 0 , ;
X
: then immediate dup here swap - swap ! ;
X
: ')' 0 ;
X
: _fix key drop key swap 2 + ! ;
X
: fix-')' immediate ' ')' _fix ;
X
fix-')' )
X
: find-) key ')' = not if tail find-) then ;
X
: ( immediate find-) ;
X
( we should be able to do FORTH-style comments now )
X
( this works as follows: ( is an immediate word, so it gets
X  control during compilation.  Then it simply reads in characters
X  until it sees a close parenthesis.  once it does, it exits.
X  if not, it pops off the return stack--manual tail recursion. )
X
( now that we've got comments, we can comment the rest of the code! )
X
: else immediate
X  ' branch ,		( compile a definite branch )
X  here			( push the backpatching address )
X  0 ,			( compile a dummy offset for branch )
X  swap			( bring old backpatch address to top )
X  dup here swap -	( calculate the offset from old address )
X  swap !		( put the address on top and store it )
;
X
: over _x! _y! _y _x _y ;
X
: add
X  _x!			( save the pointer in a temp variable )
X  _x @			( get the value pointed to )
X  +			( add the incremement from on top of the stack )
X  _x !			( and save it )
;
X
: allot	h add ;
X
: maybebranch
X  logical		( force the TOS to be 0 or 1 )
X  r @ @ @		( load the branch offset )
X  computebranch	( calculate the condition offset [either TOS or 1])
X  r @ @ +		( add it to the return address )
X  r @ !		( store it to our return address and return )
;
X
: mod _x! _y!		( get x then y off of stack )
X  _y
X  _y _x / _x *		( y - y / x * x )
X  -
;
X
: '\n' 0 ;
: '"' 0 ;
: '0' 0 ;
: 'space' 0 ;
X
: fix-'\n' immediate ' '\n' _fix ;
: fix-'"' immediate ' '"' _fix ;
: fix-'0' immediate ' '0' _fix ;
: fix-'space' immediate ' 'space' _fix ;
X
fix-'0' 0 fix-'space'  fix-'"' "
fix-'\n'
X
X
: cr '\n' echo exit
X
: printnum
X  dup
X  10 mod '0' +
X  swap 10 / dup
X  if
X    printnum 0
X  then
X  drop echo
;
X
: .
X  dup 0 <
X  if
X    45 echo minus
X  then
X  printnum
X  'space' echo
;
X
X
: debugprint dup . cr ;
X
( the following routine takes a pointer to a string, and prints it,
X  except for the trailing quote.  returns a pointer to the next word
X  after the trailing quote )
X
: _print
X  dup 1 +
X  swap @
X  dup '"' =
X  if
X    drop exit
X  then
X  echo
X  tail _print
;
X
: print _print ;
X
X  ( print the next thing from the instruction stream )
: immprint
X  r @ @
X  print
X  r @ !
;
X
: find-"
X  key dup ,
X  '"' =
X  if
X    exit
X  then
X  tail find-"
;
X
: " immediate
X  key drop
X  ' immprint ,
X  find-"
;
X
: do immediate
X  ' swap ,		( compile 'swap' to swap the limit and start )
X  ' tor ,		( compile to push the limit onto the return stack )
X  ' tor ,		( compile to push the start on the return stack )
X  here			( save this address so we can branch back to it )
;
X
: i r @ 1 - @ ;
: j r @ 3 - @ ;
X
: > swap < ;
: <= 1 + < ;
: >= swap <= ;
X
: inci 
X  r @ 1 - 	( get the pointer to i )
X  inc		( add one to it )
X  r @ 1 - @ 	( find the value again )
X  r @ 2 - @	( find the limit value )
X  <
X  if
X    r @ @ @ r @ @ + r @ ! exit		( branch )
X  then
X  fromr 1 +
X  fromr drop
X  fromr drop
X  tor
;
X  	
: loop immediate ' inci , here - , ;
X
: loopexit
X
X  fromr drop		( pop off our return address )
X  fromr drop		( pop off i )
X  fromr drop		( pop off the limit of i )
;			( and return to the caller's caller routine )
X
: isprime
X  dup 2 = if
X    exit
X  then
X  dup 2 / 2		( loop from 2 to n/2 )
X  do
X    dup			( value we're checking if it's prime )
X    i mod		( mod it by divisor )
X    not if
X      drop 0 loopexit	( exit from routine from inside loop )
X    then
X  loop 
;
X
: primes
X  " The primes from "
X  dup .
X  "  to "
X  over .
X  "  are:"
X  cr
X
X  do
X    i isprime 
X    if
X      i . 'space' echo
X    then
X  loop
X  cr
;
X
: execute
X  8 !
X  ' exit 9 !
X  8 tor
;
X
: :: ;		( :: is going to be a word that does ':' at runtime )
X
: fix-:: immediate 3 ' :: ! ;
fix-::
X
X	( Override old definition of ':' with a new one that invokes ] )
: : immediate :: ] ;
X
: command
X  here 5 !		( store dict pointer in temp variable )
X  _read			( compile a word )
X			( if we get control back: )
X  here 5 @
X  = if
X    tail command	( we didn't compile anything )
X  then
X  here 1 - h !		( decrement the dictionary pointer )
X  here 5 @		( get the original value )
X  = if
X    here @		( get the word that was compiled )
X    execute		( and run it )
X  else
X    here @		( else it was an integer constant, so push it )
X    here 1 - h !	( and decrement the dictionary pointer again )
X  then
X  tail command
;
X
: make-immediate	( make a word just compiled immediate )
X  here 1 -		( back up a word in the dictionary )
X  dup dup		( save the pointer to here )
X  h !			( store as the current dictionary pointer )
X  @			( get the run-time code pointer )
X  swap			( get the dict pointer again )
X  1 -			( point to the compile-time code pointer )
X  !			( write run-time code pointer on compile-time pointer )
;
X
: <build immediate
X  make-immediate	( make the word compiled so far immediate )
X  ' :: ,		( compile '::', so we read next word )
X  2 ,			( compile 'pushint' )
X  here 0 ,		( write out a 0 but save address for does> )
X  ' , ,			( compile a push that address onto dictionary )
;
X
: does> immediate
X  ' command ,		( jump back into command mode at runtime )
X  here swap !		( backpatch the build> to point to here )
X  2 ,			( compile run-code primitive so we look like a word )
X  ' fromr ,		( compile fromr, which leaves var address on stack )
;
X
X
: _dump			( dump out the definition of a word, sort of )
X  dup " (" . " , "
X  dup @			( save the pointer and get the contents )
X  dup ' exit
X  = if
X	" ;)" cr exit
X  then
X  . " ), "
X  1 +
X  tail _dump
;
X
: dump _dump ;
X
: # . cr ;
X  
: var <build , does> ;
: constant <build , does> @ ;
: array <build allot does> + ;
X
: [ immediate command ;
: _welcome " Welcome to THIRD.
Ok.
" ;
X
: ; immediate ' exit , command exit
X
[
X
_welcome
SHAR_EOF
  (set 20 15 03 07 14 09 28 'third/third.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/third.th'
if test $? -ne 0
then ${echo} "restore of third/third.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/third.th': 'MD5 check failed'
       ) << \SHAR_EOF
3979d5e0997d6414f457172c9a4483eb  third/third.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/third.th'` -ne 6605 && \
  ${echo} "restoration warning:  size of 'third/third.th' is not 6605"
  fi
fi
# ============= third/demo5.th ==============
if test -n "${keep_file}" && test -f 'third/demo5.th'
then
${echo} "x - SKIPPING third/demo5.th (file already exists)"
else
${echo} "x - extracting third/demo5.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo5.th' &&
( recursive factorial.  given x on top, followed by )
( an "accumulator" containing the product except for x! )
X
: fact-help2
X
X  dup if
X    swap over swap
X    *
X    swap 1 -
X    fact-help2
X  then
;
X
: fact
X
X  1 swap
X  fact-help2
X  drop
;
X
: demo5
X
X  " The factorial of 3 is: " 3 fact . cr
X  " The factorial of 5 is: " 5 fact . cr
;
X
demo5
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo5.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo5.th'
if test $? -ne 0
then ${echo} "restore of third/demo5.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo5.th': 'MD5 check failed'
       ) << \SHAR_EOF
36661f2627a4e7ca7be20a83bb4b6b5a  third/demo5.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo5.th'` -ne 339 && \
  ${echo} "restoration warning:  size of 'third/demo5.th' is not 339"
  fi
fi
# ============= third/.gitignore ==============
if test -n "${keep_file}" && test -f 'third/.gitignore'
then
${echo} "x - SKIPPING third/.gitignore (file already exists)"
else
${echo} "x - extracting third/.gitignore (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/.gitignore' &&
*.o
third
SHAR_EOF
  (set 20 15 03 07 14 13 03 'third/.gitignore'
   eval "${shar_touch}") && \
  chmod 0600 'third/.gitignore'
if test $? -ne 0
then ${echo} "restore of third/.gitignore failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/.gitignore': 'MD5 check failed'
       ) << \SHAR_EOF
04e17e9c51bd77f27ea6dfaf80ed4746  third/.gitignore
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/.gitignore'` -ne 10 && \
  ${echo} "restoration warning:  size of 'third/.gitignore' is not 10"
  fi
fi
# ============= third/demo1.1st ==============
if test -n "${keep_file}" && test -f 'third/demo1.1st'
then
${echo} "x - SKIPPING third/demo1.1st (file already exists)"
else
${echo} "x - extracting third/demo1.1st (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo1.1st' &&
: immediate _read @ ! - * / <0 exit echo key _pick
X
: show echo echo echo echo exit
: all show show show show echo exit
X
: doit immediate
X    10 33 100 108 114 111 87
X    32 111 108 108 101 72
X    all
exit
X
doit
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo1.1st'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo1.1st'
if test $? -ne 0
then ${echo} "restore of third/demo1.1st failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo1.1st': 'MD5 check failed'
       ) << \SHAR_EOF
f542f72c1da0ceafe321e7a16c7dd45e  third/demo1.1st
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo1.1st'` -ne 212 && \
  ${echo} "restoration warning:  size of 'third/demo1.1st' is not 212"
  fi
fi
# ============= third/help.th ==============
if test -n "${keep_file}" && test -f 'third/help.th'
then
${echo} "x - SKIPPING third/help.th (file already exists)"
else
${echo} "x - extracting third/help.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/help.th' &&
: help key  ( flush the carriage return form the input buffer )
X
" The following are the standard known words; words marked with (*) are
immediate words, which cannot be used from command mode, but only in
word definitions.  Words marked by (**) declare new words, so are always
followed by the new word.
X
X	! @		fetch, store
X	+ - * / mod	standard arithmetic operations
X	= < > <= >=	standard comparison operations
X
X	not		boolean not of top of stack
X	logical		turn top of stack into 0 or 1
X
X	dup over	duplicate the top of stack or second of stack
X	swap drop	reverse top two elements or drop topmost
X
X	inc dec		increment/decrement the value at address from stack
X	add		add a value from 2nd of stack into address from top
X
X	echo key	output character from, or input to, top of stack
X	. #		print out number on top of stack without/with cr
X	cr		print a carriage return
X
[more]" key
" (**)	var		declare variable with initial value taken from stack
(**)	constant	declare constant with initial value taken from stack
(**)	array		declare an array with size taken from stack
X
(*)	if...else...then	FORTH branching construct
(*)	do...loop		FORTH looping construct
X	i j			loop values (not variables)
X
X	print		print the string pointed to on screen
X
(*)(**) :		declare a new THIRD word
(*)	<build does>	declare a data types compile-time and run-time
(*)	;		terminate a word definition
X
[more]" key
" Advanced words:
X	here		current location in dictionary
X	h		pointer into dictionary
X	r		pointer to return stack
X	fromr tor	pop a value from or to the return stack
X
X	,		write the top of stack to dictionary
X	'		store the address of the following word on the stack
X	allot		leave space on the dictionary
X
X	::		compile a ':' header
X	[		switch into command mode
X	]		continue doing : definitions
" ;
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/help.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/help.th'
if test $? -ne 0
then ${echo} "restore of third/help.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/help.th': 'MD5 check failed'
       ) << \SHAR_EOF
ed49456a2a6a94ddcdd11f6b2def6b92  third/help.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/help.th'` -ne 1774 && \
  ${echo} "restoration warning:  size of 'third/help.th' is not 1774"
  fi
fi
# ============= third/buzzard.2.README ==============
if test -n "${keep_file}" && test -f 'third/buzzard.2.README'
then
${echo} "x - SKIPPING third/buzzard.2.README (file already exists)"
else
${echo} "x - extracting third/buzzard.2.README (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/buzzard.2.README' &&
buzzard.2.README	this file
buzzard.2.design	description of FIRST (design documentation of THIRD)
third			implementation of THIRD in FIRST
help.th			online listing of THIRD primitives
X
X	FIRST demos:  use  'first < {demo}'
X
demo1.1st		prints Hello World! assuming ASCII
X
X	THIRD demos:  use  'cat third {demo} | first'
X
demo1.th		prints Hello World! regardless of character set
demo2.th		demonstrates a simple loop
demo3.th		demonstrates a simple if test
demo4.th		recursive factorial calculating on the way up
demo5.th		recursive factorial calculating on the way down
demo6.th		demonstrates switching from compiler to execution mode
X
X	Interactive THIRD: use 'cat third - | first'.
X
X	To include the primitive on-line help, use
X	'cat third help.th - | first'.
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/buzzard.2.README'
   eval "${shar_touch}") && \
  chmod 0600 'third/buzzard.2.README'
if test $? -ne 0
then ${echo} "restore of third/buzzard.2.README failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/buzzard.2.README': 'MD5 check failed'
       ) << \SHAR_EOF
335f58aab335576eb8d919ab42bbb2d2  third/buzzard.2.README
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/buzzard.2.README'` -ne 756 && \
  ${echo} "restoration warning:  size of 'third/buzzard.2.README' is not 756"
  fi
fi
# ============= third/buzzard.2.orig.c ==============
if test -n "${keep_file}" && test -f 'third/buzzard.2.orig.c'
then
${echo} "x - SKIPPING third/buzzard.2.orig.c (file already exists)"
else
${echo} "x - extracting third/buzzard.2.orig.c (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/buzzard.2.orig.c' &&
#define c 0 [m] ++ [m] =
#define z;break;case
X
char s[5000];
int m[20000]={32},L=1,I,T[500],*S=T,t=64,w,f;
X
a(x)
{
X   c L;
X   L= *m-1;
X   c t;
X   c x;
X   scanf("%s",s+t);
X   t+=strlen(s+t)+1;
}
X
r(x)
{
X   switch(x++[m]){
X	z 5:	for(w=scanf("%s",s)<1?exit(0):L;strcmp(s,&w[&m[1]][s]);w=m[w]);
X		w-1 ? r(w+2) : (c 2,c atoi(s))
X	z 12:	I=1[m]--[m]
X	z 15:	f=S[-f]
X	z 1:	c x 
X	z 9:	f *=* S--
X	z 7:	m[f]= *S--;
X		f= *S--
X	z 0:	*++S=f;
X		f=I++[m]
X	z 8:	f= *S --- f
X	z 2:	m[++1[m]]=I;
X		I=x
X	z 11:	f=0>f
X	z 4:	*m-=2;c 2
X	z 6:	f=f[m]
X	z 10:	f= *S--/f
X	z 3:	a(1);
X		c 2
X	z 13:	putchar(f);
X		f= *S--
X	z 14:	*++S=f;
X		f=getchar();
X   }
}
X
main()
{
X   a(3);
X   a(4);
X   a(1);
X   w= *m;
X   c 5;
X   c 2;
X   I= *m;
X   c w;
X   c I-1;
X   for(w=6;w<16;)
X      a(1),c w++;
X   m[1]= *m;
X   for(*m+=512;;r(m[I++]));
}
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/buzzard.2.orig.c'
   eval "${shar_touch}") && \
  chmod 0600 'third/buzzard.2.orig.c'
if test $? -ne 0
then ${echo} "restore of third/buzzard.2.orig.c failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/buzzard.2.orig.c': 'MD5 check failed'
       ) << \SHAR_EOF
6b27776ebe66e87ab1abcbc6c0aec036  third/buzzard.2.orig.c
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/buzzard.2.orig.c'` -ne 794 && \
  ${echo} "restoration warning:  size of 'third/buzzard.2.orig.c' is not 794"
  fi
fi
# ============= third/demo4.th ==============
if test -n "${keep_file}" && test -f 'third/demo4.th'
then
${echo} "x - SKIPPING third/demo4.th (file already exists)"
else
${echo} "x - extracting third/demo4.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo4.th' &&
( compute factorial recursively )
( take x as input, return x! and x as output )
X
: fact-help
X
X  dup if
X    1 -			( leave x-1 on top )
X    fact-help		( leave x-1, [x-1]! )
X    1 +			( leave x, [x-1]!, x )
X    swap over swap	( leave [x-1]!, x, x )
X    *			( into x!, x )
X    swap		( into x, x! )
X  else
X    1 swap
X  then
;
X
: fact
X
X  fact-help
X  drop
X
;
X
: demo4
X  " 4 factorial is: " 4 fact . cr
X  " 6 factorial is: " 6 fact . cr
;
X
demo4
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo4.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo4.th'
if test $? -ne 0
then ${echo} "restore of third/demo4.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo4.th': 'MD5 check failed'
       ) << \SHAR_EOF
06db4bb3f26e4be476845274c6d14698  third/demo4.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo4.th'` -ne 439 && \
  ${echo} "restoration warning:  size of 'third/demo4.th' is not 439"
  fi
fi
# ============= third/demo1.th ==============
if test -n "${keep_file}" && test -f 'third/demo1.th'
then
${echo} "x - SKIPPING third/demo1.th (file already exists)"
else
${echo} "x - extracting third/demo1.th (text)"
  sed 's/^X//' << 'SHAR_EOF' > 'third/demo1.th' &&
: demo1 " Hello world!
" ;
X
demo1
SHAR_EOF
  (set 20 14 09 10 09 12 08 'third/demo1.th'
   eval "${shar_touch}") && \
  chmod 0600 'third/demo1.th'
if test $? -ne 0
then ${echo} "restore of third/demo1.th failed"
fi
  if ${md5check}
  then (
       ${MD5SUM} -c >/dev/null 2>&1 || ${echo} 'third/demo1.th': 'MD5 check failed'
       ) << \SHAR_EOF
54a11e88533d1ba0f6d127fd63ec9d7b  third/demo1.th
SHAR_EOF
  else
test `LC_ALL=C wc -c < 'third/demo1.th'` -ne 34 && \
  ${echo} "restoration warning:  size of 'third/demo1.th' is not 34"
  fi
fi
if rm -fr ${lock_dir}
then ${echo} "x - removed lock directory ${lock_dir}."
else ${echo} "x - failed to remove lock directory ${lock_dir}."
     exit 1
fi
exit 0
